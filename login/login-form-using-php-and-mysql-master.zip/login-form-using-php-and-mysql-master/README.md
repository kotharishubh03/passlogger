## A simple Login and Signup form using PHP and MySQL
### Login Page
![](https://i.imgur.com/Pi48U2Y.png)
### Signup Page                                                          
![](https://i.imgur.com/I7YwJhQ.png)
### Database Creation                                                            
![](https://i.imgur.com/YiAaBSk.png)                           
                           
                                                          
